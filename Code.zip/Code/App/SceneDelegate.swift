//
//  SceneDelegate.swift
//  ExpenseSplitter
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    
    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        let context = CoreDataStack.shared.viewContext
        let groupsListViewModel = GroupsListViewModel(context: context)
        let groupsListViewController = GroupsListViewController(viewModel: groupsListViewModel)
        let navigationController = UINavigationController(rootViewController: groupsListViewController)

        navigationController.navigationBar.prefersLargeTitles = true
        navigationController.navigationBar.tintColor = Theme.Colors.primary

        let window = UIWindow(windowScene: windowScene)
        window.backgroundColor = Theme.Colors.background
        window.rootViewController = navigationController
        window.tintColor = Theme.Colors.primary
        self.window = window
        window.makeKeyAndVisible()
    }

    func sceneDidDisconnect(_ scene: UIScene) {}

    func sceneDidBecomeActive(_ scene: UIScene) {}

    func sceneWillResignActive(_ scene: UIScene) {}

    func sceneWillEnterForeground(_ scene: UIScene) {}

    func sceneDidEnterBackground(_ scene: UIScene) {
        CoreDataStack.shared.saveContext()
    }


}

